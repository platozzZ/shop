(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/uni-load-more"],{7534:function(t,n,e){"use strict";var u=e("c59d"),o=e.n(u);o.a},"9c3d":function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var u={name:"load-more",props:{loadingType:{type:Number,default:0},showImage:{type:Boolean,default:!0},color:{type:String,default:"#777777"},contentText:{type:Object,default:function(){return{contentdown:"上拉显示更多",contentrefresh:"正在加载...",contentnomore:"没有更多数据了"}}}},data:function(){return{}}};n.default=u},c59d:function(t,n,e){},d241:function(t,n,e){"use strict";var u,o=function(){var t=this,n=t.$createElement;t._self._c},r=[];e.d(n,"b",(function(){return o})),e.d(n,"c",(function(){return r})),e.d(n,"a",(function(){return u}))},ef75:function(t,n,e){"use strict";e.r(n);var u=e("d241"),o=e("f2f4");for(var r in o)"default"!==r&&function(t){e.d(n,t,(function(){return o[t]}))}(r);e("7534");var c,a=e("f0c5"),f=Object(a["a"])(o["default"],u["b"],u["c"],!1,null,null,null,!1,u["a"],c);n["default"]=f.exports},f2f4:function(t,n,e){"use strict";e.r(n);var u=e("9c3d"),o=e.n(u);for(var r in u)"default"!==r&&function(t){e.d(n,t,(function(){return u[t]}))}(r);n["default"]=o.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/uni-load-more-create-component',
    {
        'components/uni-load-more-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("ef75"))
        })
    },
    [['components/uni-load-more-create-component']]
]);
